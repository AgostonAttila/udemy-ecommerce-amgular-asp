export type DeliveryMethod = {
    shortName: string;
    deliveryTime: string;
    description: string;
    price: number;
    id: number;
}