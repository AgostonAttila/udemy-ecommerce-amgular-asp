export const environment = {
    production: true,
    apiUrl: 'api/',
    hubUrl: 'hub/notifications',
    stripePublicKey: 'pk_test_51PgNeJHFp6sM7BvVtVfkgmbYOKiC54ubqwGxUst96RWFRFjaT40Mv2mJ2lCGFRYQ7F3EzRYkmgstzULkEkstnJP100FwHuwVNk'
};

