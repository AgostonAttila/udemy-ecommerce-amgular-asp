export const environment = {
    production: false,
    apiUrl: 'https://localhost:5001/api/',
    hubUrl: 'https://localhost:5001/hub/notifications',
    stripePublicKey: 'pk_test_51PeXuWHV9KPhYMymy0FJpQRoP5sPhsN3CmZwIrUcDf9l46nOKFHkqefnDp3nRiBWA0PLkzNvfpvVTCaikCk6V3yH008P5RbZDa'
};
