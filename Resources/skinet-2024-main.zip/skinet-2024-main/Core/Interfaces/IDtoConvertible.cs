﻿namespace Core.Interfaces;

public interface IDtoConvertible
{

}
